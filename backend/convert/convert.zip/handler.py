import boto3
import uuid
import os
import json
from datetime import datetime

polly = boto3.client("polly")
s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

BUCKET_NAME = os.environ.get("BUCKET_NAME")
TABLE_NAME = os.environ.get("TABLE_NAME")

def lambda_handler(event, context):
    try:
        
        body = json.loads(event.get("body", "{}"))
        text = body.get("text", "").strip()
        if not text:
            return {"statusCode": 400, "body": json.dumps({"error":"text is required"})}

        # user id from Cognito authorizer claims (HTTP API / Cognito)
        user_id = event.get("requestContext", {}).get("authorizer", {}).get("claims", {}).get("sub", "anonymous")

        # Polly synthesize
        response = polly.synthesize_speech(Text=text, OutputFormat="mp3", VoiceId="Joanna")
        audio_stream = response.get("AudioStream")
        if audio_stream is None:
            return {"statusCode": 500, "body": json.dumps({"error":"Polly returned no audio"})}

        audio_bytes = audio_stream.read()
        audio_key = f"{user_id}/{uuid.uuid4()}.mp3"

        # put into S3
        s3.put_object(Bucket=BUCKET_NAME, Key=audio_key, Body=audio_bytes, ContentType="audio/mpeg")

        # save metadata to DynamoDB
        table = dynamodb.Table(TABLE_NAME)
        item = {
            "user_id": user_id,
            "timestamp": datetime.utcnow().isoformat(),
            "audio_key": audio_key,
            "text": text
        }
        table.put_item(Item=item)

        # generate a presigned URL (valid for 1 hour)
        audio_url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": BUCKET_NAME, "Key": audio_key},
            ExpiresIn=3600
        )

        return {
            "statusCode": 200,
            "body": json.dumps({"message":"success", "audio_url": audio_url})
        }

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
